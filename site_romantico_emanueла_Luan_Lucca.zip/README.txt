SITE ROMÂNTICO PARA ELA ❤️

1. Abra a pasta do site.
2. Coloque o arquivo da música "Caju - Liniker" dentro de:
   assets/caju.mp3
3. Abra index.html no navegador.

Para publicar de graça:
- GitHub Pages
- Netlify
- Vercel

O site já está responsivo para celular.
As três imagens foram recortadas dos prints enviados e receberam uma moldura circular com efeito de sol radiante.

IMPORTANTE:
O arquivo da música não foi incluído. Você precisa usar uma cópia do áudio que tenha direito de utilizar.
